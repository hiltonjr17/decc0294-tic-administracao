#!/usr/bin/env python3
"""Gera mapa da eleição para governador do Maranhão por ano e turno.

Entrada:
  API JSON oficial do TSE em 2026; ZIP de votação por seção nos anos anteriores
  municipios_ma.geojson      — malha municipal do Maranhão (217 municípios)

Saídas:
  mapa_governador_ma_<ano>_turno_<turno>.png/.html e tabelas CSV
"""
from __future__ import annotations
import csv
import json
import math
import os
import re
import unicodedata
import zipfile
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path as MplPath
from matplotlib.patches import PathPatch

ROOT = Path(__file__).resolve().parent
ELECTION_YEAR = int(os.environ.get("ELECTION_YEAR", "2026"))
ELECTION_TURN = int(os.environ.get("ELECTION_TURN", "1"))
ZIP_PATH = ROOT / f"votacao_secao_{ELECTION_YEAR}_MA.zip"
GEO_PATH = ROOT / "municipios_ma.geojson"
OUT_PNG = ROOT / f"mapa_governador_ma_{ELECTION_YEAR}_turno_{ELECTION_TURN}.png"
OUT_HTML = ROOT / f"mapa_governador_ma_{ELECTION_YEAR}_turno_{ELECTION_TURN}.html"
OUT_LONG = ROOT / f"votos_municipais_por_candidato_{ELECTION_YEAR}_turno_{ELECTION_TURN}.csv"
OUT_WIN = ROOT / f"lideranca_municipal_governador_{ELECTION_YEAR}_turno_{ELECTION_TURN}.csv"


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = s.lower().strip()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def candidate_label(name: str) -> str:
    aliases = {
        "carlos orleans brandao junior": "Carlos Brandão",
        "edivaldo de holanda braga junior": "Edivaldo Holanda Jr.",
        "enilton silva rodrigues": "Enilton Rodrigues",
        "frankle da costa lima": "Frankle Costa",
        "hertz da conceicao dias": "Hertz Dias",
        "joas moraes dos santos": "Joás Moraes",
        "jose simplicio alves de araujo": "Simplício Araújo",
        "lahesio rodrigues do bonfim": "Lahesio Bonfim",
        "weverton rocha marques de sousa": "Weverton Rocha",
    }
    return aliases.get(norm(name), str(name).title())


def int_value(s: str) -> int:
    s = str(s or "").strip().replace(".", "").replace(",", "")
    try:
        return int(float(s))
    except (ValueError, TypeError):
        return 0


def find_column(header: list[str], *options: str) -> str | None:
    lut = {norm(h): h for h in header}
    for op in options:
        if norm(op) in lut:
            return lut[norm(op)]
    return None


def read_api_results():
    """Busca o cargo de governador diretamente nos JSON oficiais do TSE 2026."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from threading import local
    import time
    import requests

    election_codes = {1: 6259, 2: 6260}
    if ELECTION_TURN not in election_codes:
        raise ValueError("Para a API TSE 2026, ELECTION_TURN deve ser 1 ou 2.")
    election_code = election_codes[ELECTION_TURN]
    base = f"https://resultados.tse.jus.br/oficial/ele2026/{election_code}"
    headers = {"User-Agent": "Mozilla/5.0 (compatible; mapa-eleitoral/1.0)"}
    cache_dir = ROOT / f"api_cache_2026_turno_{ELECTION_TURN}"
    cache_dir.mkdir(exist_ok=True)
    thread_state = local()

    def get_json(url, cache_path=None):
        if cache_path and cache_path.exists():
            return json.loads(cache_path.read_text(encoding="utf-8"))
        if not hasattr(thread_state, "session"):
            thread_state.session = requests.Session()
            thread_state.session.headers.update(headers)
        for attempt in range(5):
            try:
                response = thread_state.session.get(url, timeout=(15, 60))
                response.raise_for_status()
                data = response.json()
                if cache_path:
                    cache_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
                return data
            except (requests.Timeout, requests.ConnectionError) as exc:
                if attempt == 4:
                    raise
                time.sleep(min(2 ** attempt, 8))

    election_suffix = f"e{election_code:06d}"
    config_url = f"{base}/config/mun-{election_suffix}-cm.json"
    config = get_json(config_url, cache_dir / "config.json")
    ma = next((state for state in config.get("abr", []) if state.get("cd") == "ma"), None)
    municipalities = ma.get("mu", []) if ma else []
    if len(municipalities) != 217:
        raise RuntimeError(f"A configuração do TSE retornou {len(municipalities)} municípios para MA, esperado 217.")

    def candidate_rows(data):
        office = next((x for x in data.get("carg", []) if str(x.get("cd")) == "3"), None)
        if not office:
            raise RuntimeError("O JSON do TSE não contém o cargo Governador.")
        for coalition in office.get("agr", []):
            for party in coalition.get("par", []):
                party_code = str(party.get("sg") or party.get("com") or "").strip()
                for candidate in party.get("cand", []):
                    name = str(candidate.get("nmu") or candidate.get("nm") or "").strip()
                    if name:
                        yield name, int_value(candidate.get("vap", "0")), party_code

    state_url = f"{base}/dados/ma/ma-c0003-{election_suffix}-u.json"
    state_json = get_json(state_url, cache_dir / "resultado_estadual.json")
    if state_json.get("and") != "f":
        print("Aviso: a totalização estadual do TSE ainda não está marcada como encerrada.")
    state_totals = defaultdict(int)
    for name, votes, _party in candidate_rows(state_json):
        state_totals[norm(name)] += votes

    def fetch_municipality(mun):
        code = str(mun["cd"]).zfill(5)
        url = f"{base}/dados/ma/ma{code}-c0003-{election_suffix}-u.json"
        data = get_json(url, cache_dir / f"municipio_{code}.json")
        rows = list(candidate_rows(data))
        return mun, rows

    totals = defaultdict(int)
    parties = defaultdict(set)
    completed = 0
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(fetch_municipality, mun) for mun in municipalities]
        for future in as_completed(futures):
            mun, rows = future.result()
            city = norm(mun["nm"])
            for candidate, votes, party in rows:
                key = (city, candidate)
                totals[key] += votes
                if party:
                    parties[key].add(party)
            completed += 1
            if completed % 25 == 0 or completed == len(municipalities):
                print(f"API TSE: {completed}/{len(municipalities)} municípios consultados.", flush=True)

    summed_state = defaultdict(int)
    for (_city, candidate), votes in totals.items():
        summed_state[norm(candidate)] += votes
    discrepancies = {
        name: (state_totals.get(name, 0), summed_state.get(name, 0))
        for name in set(state_totals) | set(summed_state)
        if state_totals.get(name, 0) != summed_state.get(name, 0)
    }
    if discrepancies:
        raise RuntimeError(f"Totais municipais não fecham com o JSON estadual do TSE: {discrepancies}")
    print(f"API TSE: {len(municipalities)} municípios; turno {ELECTION_TURN}; arquivo estadual gerado {state_json.get('dg')} {state_json.get('hg')}.")
    return totals, parties


def read_results():
    if ELECTION_YEAR == 2026:
        return read_api_results()
    if not ZIP_PATH.exists():
        raise FileNotFoundError(f"Arquivo TSE não encontrado: {ZIP_PATH}")
    with zipfile.ZipFile(ZIP_PATH) as zf:
        csv_names = [n for n in zf.namelist() if n.lower().endswith(".csv")]
        if not csv_names:
            raise RuntimeError("Não há CSV dentro do ZIP do TSE.")
        with zf.open(csv_names[0]) as raw:
            # Arquivos TSE são geralmente Latin-1 e separados por ponto e vírgula.
            import io
            text = io.TextIOWrapper(raw, encoding="latin-1", newline="")
            reader = csv.DictReader(text, delimiter=";")
            header = reader.fieldnames or []
            col = {
                "uf": find_column(header, "SG_UF"),
                "turno": find_column(header, "NR_TURNO"),
                "cargo": find_column(header, "CD_CARGO"),
                "cargo_nome": find_column(header, "DS_CARGO"),
                "municipio": find_column(header, "NM_MUNICIPIO"),
                "nome": find_column(header, "NM_VOTAVEL", "NM_URNA_CANDIDATO", "NM_CANDIDATO"),
                "partido": find_column(header, "SG_PARTIDO"),
                "votos": find_column(header, "QT_VOTOS", "QT_VOTOS_NOMINAIS"),
            }
            missing = [k for k in ("municipio", "nome", "votos") if not col[k]]
            if missing:
                raise RuntimeError(f"Campos essenciais não encontrados ({missing}); cabeçalho: {header}")
            totals = defaultdict(int)
            parties = defaultdict(set)
            for row in reader:
                if col["uf"] and row.get(col["uf"], "").strip().upper() != "MA":
                    continue
                if col["turno"] and int_value(row.get(col["turno"], "")) != ELECTION_TURN:
                    continue
                cargo_code = int_value(row.get(col["cargo"], "")) if col["cargo"] else None
                cargo_name = norm(row.get(col["cargo_nome"], "")) if col["cargo_nome"] else ""
                if cargo_code is not None and cargo_code != 3 and "governador" not in cargo_name:
                    continue
                if cargo_code is None and "governador" not in cargo_name:
                    continue
                city = row.get(col["municipio"], "").strip()
                candidate = row.get(col["nome"], "").strip()
                if not city or not candidate:
                    continue
                nc = norm(candidate)
                # Remove os registros de votos não nominais que também constam no arquivo por seção.
                if any(x in nc for x in ("voto branco", "voto nulo", "voto anul", "voto legenda", "branco", "nulo")):
                    continue
                votes = int_value(row.get(col["votos"], ""))
                if votes <= 0:
                    continue
                key = (norm(city), candidate)
                totals[key] += votes
                if col["partido"] and row.get(col["partido"], "").strip():
                    parties[key].add(row[col["partido"]].strip())
    return totals, parties


def geometry_paths(geometry):
    """Yield outer-ring coordinate arrays from a GeoJSON Polygon/MultiPolygon."""
    typ = geometry["type"]
    coords = geometry["coordinates"]
    polys = [coords] if typ == "Polygon" else coords if typ == "MultiPolygon" else []
    for poly in polys:
        for ring_i, ring in enumerate(poly):
            # Interior holes are retained as separate compound subpaths.
            pts = list(ring)
            if len(pts) < 3:
                continue
            yield ring_i, pts


def main():
    totals, parties = read_results()
    geo = json.loads(GEO_PATH.read_text(encoding="utf-8"))
    features = geo.get("features", [])
    if len(features) != 217:
        print(f"Aviso: a malha tem {len(features)} polígonos; esperado 217 municípios.")

    geo_by_name = {}
    for f in features:
        props = f["properties"]
        geo_by_name[norm(props.get("name", ""))] = f

    city_candidates = defaultdict(list)
    for (city_key, candidate), votes in totals.items():
        city_candidates[city_key].append((candidate, votes, sorted(parties.get((city_key, candidate), set()))))

    winners = {}
    long_rows = []
    for city_key, f in geo_by_name.items():
        props = f["properties"]
        choices = city_candidates.get(city_key, [])
        if not choices:
            # Sem dados, sinaliza erro em vez de preencher com dado inventado.
            continue
        choices.sort(key=lambda x: (-x[1], norm(x[0])))
        valid_votes = sum(x[1] for x in choices)
        winner, winner_votes, win_parties = choices[0]
        party = win_parties[0] if win_parties else ""
        ibge = str(props.get("id", ""))
        winners[city_key] = {
            "code_ibge": ibge, "municipio": props.get("name", ""),
            "candidate_winner": winner, "party_winner": party,
            "candidate_label": candidate_label(winner),
            "votes_winner": winner_votes, "valid_candidate_votes": valid_votes,
            "winner_share_pct": 100 * winner_votes / valid_votes if valid_votes else 0,
        }
        for candidate, votes, party_set in choices:
            long_rows.append({
                "code_ibge": ibge, "municipio": props.get("name", ""),
                "candidato": candidate, "partido": "/".join(party_set),
                "votos": votes, "votos_validos_candidatos_municipio": valid_votes,
                "percentual_votos_validos": 100 * votes / valid_votes if valid_votes else 0,
            })

    missing = sorted(set(geo_by_name) - set(winners))
    extra = sorted(set(city_candidates) - set(geo_by_name))
    print(f"Municípios com dados: {len(winners)}/{len(features)}")
    if missing:
        print("Sem correspondência na tabela eleitoral:", [geo_by_name[k]["properties"].get("name") for k in missing])
    if extra:
        print("Nomes eleitorais não encontrados na malha:", [k for k in extra[:15]])
    if len(winners) != len(features):
        raise RuntimeError("A junção deixou municípios sem dados; interrompendo para evitar mapa incompleto.")

    with OUT_LONG.open("w", encoding="utf-8-sig", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(long_rows[0].keys()))
        w.writeheader(); w.writerows(long_rows)
    with OUT_WIN.open("w", encoding="utf-8-sig", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(next(iter(winners.values())).keys()))
        w.writeheader(); w.writerows(sorted(winners.values(), key=lambda r: norm(r["municipio"])))

    # Paleta categórica para o candidato mais votado em cada município.
    state_totals = defaultdict(int)
    candidate_party = defaultdict(set)
    municipal_count = defaultdict(int)
    for (city_key, candidate), votes in totals.items():
        state_totals[candidate] += votes
        candidate_party[candidate].update(parties.get((city_key, candidate), set()))
    for record in winners.values():
        municipal_count[record["candidate_winner"]] += 1
    order = sorted(municipal_count, key=lambda c: (-municipal_count[c], -state_totals[c], norm(c)))
    palette = ["#3659A8", "#D88919", "#14866D", "#A44883", "#7B61A8", "#C65353", "#4E7A9E", "#76823B", "#BA6F4E"]
    colors = {name: palette[i % len(palette)] for i, name in enumerate(order)}

    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "axes.facecolor": "#F7F8F6",
        "figure.facecolor": "#F7F8F6",
        "text.color": "#19242D",
        "savefig.facecolor": "#F7F8F6",
    })
    fig = plt.figure(figsize=(14, 10), dpi=180)
    source_method = "API de resultados" if ELECTION_YEAR == 2026 else "votação por seção"
    fig.text(.065, .935, "ELEIÇÃO PARA GOVERNADOR", fontsize=11, weight="bold", color="#657582", va="top")
    fig.text(.065, .892, f"Maranhão, {ELECTION_YEAR}", fontsize=29, weight="bold", color="#172A3A", va="top")
    fig.text(.065, .848, f"Candidato mais votado em cada município · {ELECTION_TURN}º turno", fontsize=13, color="#4E5F6A", va="top")

    ax = fig.add_axes([.045, .105, .64, .70])
    ax.set_axis_off(); ax.set_aspect("equal")
    mean_lat = sum(y for f in features for poly in (f["geometry"]["coordinates"] if f["geometry"]["type"] == "MultiPolygon" else [f["geometry"]["coordinates"]]) for ring in poly[:1] for x,y in ring) / max(1, sum(len(ring) for f in features for poly in (f["geometry"]["coordinates"] if f["geometry"]["type"] == "MultiPolygon" else [f["geometry"]["coordinates"]]) for ring in poly[:1]))
    x_scale = math.cos(math.radians(mean_lat))
    xs, ys = [], []
    for f in features:
        rec = winners[norm(f["properties"].get("name", ""))]
        face = colors[rec["candidate_winner"]]
        geom = f["geometry"]
        all_polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
        for poly in all_polys:
            # Draw each outer ring as an individual administrative polygon.
            ring = poly[0]
            xy = [(pt[0] * x_scale, pt[1]) for pt in ring]
            xs.extend(x for x,y in xy); ys.extend(y for x,y in xy)
            if len(xy) < 3: continue
            verts = xy + [xy[0]]
            codes = [MplPath.MOVETO] + [MplPath.LINETO] * (len(xy)-1) + [MplPath.CLOSEPOLY]
            ax.add_patch(PathPatch(MplPath(verts, codes), facecolor=face, edgecolor="#FFFFFF", linewidth=.40, antialiased=True))
    if xs:
        pad_x = (max(xs)-min(xs))*.035; pad_y = (max(ys)-min(ys))*.035
        ax.set_xlim(min(xs)-pad_x, max(xs)+pad_x); ax.set_ylim(min(ys)-pad_y, max(ys)+pad_y)

    # Painel lateral com legenda e resultado estadual.
    x0, y0 = .73, .775
    fig.text(x0, y0, "LEGENDA", fontsize=10, weight="bold", color="#657582", va="top")
    y = y0 - .045
    for name in order:
        label = candidate_label(name)
        fig.patches.append(plt.Rectangle((x0, y-.012), .017, .017, transform=fig.transFigure, facecolor=colors[name], edgecolor="none"))
        fig.text(x0+.027, y-.004, label, fontsize=10, color="#263640", va="center")
        fig.text(.956, y-.004, f"{municipal_count[name]}", fontsize=10, weight="bold", color="#263640", ha="right", va="center")
        y -= .042
    fig.text(x0, y-.008, "municípios", fontsize=8.5, color="#74828A", va="top")

    y -= .070
    fig.text(x0, y, "TOTAL ESTADUAL", fontsize=10, weight="bold", color="#657582", va="top")
    y -= .042
    total_valid = sum(state_totals.values())
    state_order = sorted(state_totals, key=lambda c: (-state_totals[c], norm(c)))
    for name in state_order[:4]:
        share = 100 * state_totals[name] / total_valid if total_valid else 0
        name_label = candidate_label(name)
        if len(name_label) > 25: name_label = name_label[:24] + "…"
        fig.text(x0, y, name_label, fontsize=9.3, color="#35454E", va="center")
        fig.text(.956, y, f"{share:.1f}%", fontsize=9.5, weight="bold", color="#172A3A", ha="right", va="center")
        fig.text(x0, y-.023, f"{state_totals[name]:,}".replace(",", ".") + " votos", fontsize=8.2, color="#74828A", va="center")
        y -= .063

    fig.text(x0, .245, "COMO LER", fontsize=10, weight="bold", color="#657582", va="top")
    fig.text(x0, .208, "Cada município recebe a cor\ndo candidato com maior votação.\nA legenda mostra quantos municípios\ncada candidato liderou.", fontsize=9.3, color="#35454E", va="top", linespacing=1.45)

    fig.text(.065, .060, f"Fonte: TSE · {source_method} (MA, {ELECTION_YEAR}, {ELECTION_TURN}º turno). Malha municipal: geodata-br, baseada no IBGE.", fontsize=8.3, color="#73818A", va="bottom")
    fig.text(.065, .035, "Percentuais estaduais calculados sobre os votos nominais contabilizados para candidatos.", fontsize=8.3, color="#73818A", va="bottom")
    fig.savefig(OUT_PNG, bbox_inches="tight", dpi=180)
    plt.close(fig)

    # Versão interativa do mesmo mapa com hover por município.
    try:
        import pandas as pd
        import plotly.express as px
        data = list(winners.values())
        df = pd.DataFrame(data)
        df["candidate_label"] = df["candidate_winner"].map(candidate_label)
        figi = px.choropleth(
            df, geojson=geo, locations="code_ibge", featureidkey="properties.id",
            color="candidate_label", color_discrete_map={candidate_label(k): v for k, v in colors.items()},
            hover_name="municipio",
            hover_data={"candidate_label": True, "votes_winner": ":,", "winner_share_pct": ":.1f", "code_ibge": False},
            labels={"candidate_label":"Líder municipal", "votes_winner":"Votos do líder", "winner_share_pct":"Parcela dos votos válidos (%)"},
            title=f"Eleição para governador do Maranhão · {ELECTION_YEAR} · {ELECTION_TURN}º turno",
        )
        figi.update_geos(fitbounds="locations", visible=False, projection_type="mercator")
        figi.update_traces(marker_line_color="white", marker_line_width=.35)
        figi.update_layout(
            title={"x":.05, "xanchor":"left", "font":{"size":22}},
            margin={"l":25,"r":25,"t":90,"b":25},
            legend_title_text="Candidato mais votado",
            paper_bgcolor="#F7F8F6", plot_bgcolor="#F7F8F6",
            font={"family":"Arial, sans-serif","color":"#172A3A"},
            height=900,
        )
        figi.write_html(OUT_HTML, include_plotlyjs=True, full_html=True)
    except Exception as e:
        print("Versão interativa não gerada:", repr(e))

    print(f"Mapa salvo: {OUT_PNG}")
    print(f"CSV candidato-município: {OUT_LONG}")
    print(f"CSV líder-município: {OUT_WIN}")
    if OUT_HTML.exists(): print(f"Mapa interativo: {OUT_HTML}")

if __name__ == "__main__":
    main()
